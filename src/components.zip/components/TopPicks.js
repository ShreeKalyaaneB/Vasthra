import React, { useRef } from 'react';
import './TopPicks.css';

const TopPicks = () => {
  const containerRef = useRef(null);

  const scrollRight = () => {
    containerRef.current.scrollTo({
      left: containerRef.current.scrollLeft + containerRef.current.offsetWidth,
      behavior: 'smooth',
    });
  };

  const scrollLeft = () => {
    containerRef.current.scrollTo({
      left: containerRef.current.scrollLeft - containerRef.current.offsetWidth,
      behavior: 'smooth',
    });
  };

  return (
    
    <section>
    <div  className="top-picks-section">
  <h2>Top Picks</h2>
  <div className="top-picks-wrapper" ref={containerRef}>
    <div className="top-picks-container">


      <div className="card">
        <img src="slide1.jpg" alt="Saree 1" />
        <button className="piclbut">Add to cart</button>
        <h3>Saree 1</h3>
        <p>Description of Saree 1</p>
      </div>


      <div className="card">
        <img src="vas.png" alt="Saree 2" />
        <button className="piclbut">Add to cart</button>

        <h3>Saree 2</h3>
        <p>Description of Saree 2</p>
      </div>

      <div className="card">
        <img src="slide1.jpg" alt="Saree 3" />
        <button className="piclbut">Add to cart</button>

        <h3>Saree 3</h3>
        <p>Description of Saree 3</p>
      </div>


      <div className="card">
        <img src="saree4.jpg" alt="Saree 4" />
        <button className="piclbut">Add to cart</button>

        <h3>Saree 4</h3>
        <p>Description of Saree 4</p>
      </div>


      <div className="card">
        <img src="saree5.jpg" alt="Saree 5" />
        <button className="piclbut">Add to cart</button>

        <h3>Saree 5</h3>
        <p>Description of Saree 5</p>
      </div>
    </div>
  </div>
    
  <div className="carousel-arrows">
    <span className="arrow-left"  onClick={scrollLeft}>
      &#8249;
    </span>
    <span className="arrow-right" onClick={scrollRight}>
      &#8250;
    </span>
  </div>
  </div>  
</section>
  );
};

export default TopPicks;
